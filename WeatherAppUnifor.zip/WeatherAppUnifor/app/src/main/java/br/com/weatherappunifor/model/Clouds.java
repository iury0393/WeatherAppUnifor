package br.com.weatherappunifor.model;

public class Clouds {
    private long all;

    public Clouds() {
    }

    public long getAll() {
        return all;
    }

    public void setAll(long all) {
        this.all = all;
    }
}
